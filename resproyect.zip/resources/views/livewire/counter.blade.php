<div style="text-align: center">
    {{ $count }}
    <button wire:click="increment">+</button>
</div>