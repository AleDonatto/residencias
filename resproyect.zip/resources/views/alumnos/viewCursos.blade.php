<h4 class="font-sans text-gray-600 font-bold text-2xl my-2">Cursos</h4>
@livewire('alumnos-cursos')