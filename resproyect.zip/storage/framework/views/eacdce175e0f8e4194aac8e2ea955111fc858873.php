<div>
    <?php if(empty($temas)): ?>
        <h4 class="text-xl mx-3 text-blue-800">No hay temas agregados</h4>
    <?php else: ?>
        <?php $__currentLoopData = $temas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h4 class="text-xl mx-3 text-blue-800"><?php echo e($item->indice.' .- '.$item->nombreTema); ?></h4>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('subtemas', ['idTema' => $item->idTema])->html();
} elseif ($_instance->childHasBeenRendered('QkzRgvm')) {
    $componentId = $_instance->getRenderedChildComponentId('QkzRgvm');
    $componentTag = $_instance->getRenderedChildComponentTagName('QkzRgvm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('QkzRgvm');
} else {
    $response = \Livewire\Livewire::mount('subtemas', ['idTema' => $item->idTema]);
    $html = $response->html();
    $_instance->logRenderedChild('QkzRgvm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:subtemas>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>
<?php /**PATH C:\laragon\www\resproyect\resources\views/livewire/temas-materia.blade.php ENDPATH**/ ?>