<div style="text-align: center">
    <?php echo e($count); ?>

    <button wire:click="increment">+</button>
</div><?php /**PATH C:\laragon\www\resproyect\resources\views/livewire/counter.blade.php ENDPATH**/ ?>