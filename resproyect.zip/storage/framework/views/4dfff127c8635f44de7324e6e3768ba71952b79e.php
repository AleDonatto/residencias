 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header'); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          <?php echo e(__('Datos Socioeconomicos')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto px-4">
        <h2 class="font-sans text-2xl text-gray-800 mx-4 my-4">
            <?php echo e(__('Mis Cursos')); ?>

        </h2>
        
        <div class="max-w-2xl mx-auto">
            <ul class="flex border-b">
                <li class="-mb-px mr-1">
                    <a class="bg-white inline-block border-l border-t border-r rounded-t py-2 px-4 text-blue-700 font-semibold" href="#">Cusos Actuales</a>
                </li>
                <li class="mr-1">
                    <a class="bg-white inline-block py-2 px-4 text-blue-500 hover:text-blue-800 font-semibold" href="#">Todo los Cursos</a>
                </li>
            </ul>
        </div>

        <div class="mt-5">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('cursos-docente')->html();
} elseif ($_instance->childHasBeenRendered('tohcdrm')) {
    $componentId = $_instance->getRenderedChildComponentId('tohcdrm');
    $componentTag = $_instance->getRenderedChildComponentTagName('tohcdrm');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tohcdrm');
} else {
    $response = \Livewire\Livewire::mount('cursos-docente');
    $html = $response->html();
    $_instance->logRenderedChild('tohcdrm', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH C:\laragon\www\resproyect\resources\views/docente/misCursos.blade.php ENDPATH**/ ?>