<div>
    <?php $__currentLoopData = $subtemas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="mx-5 text-sm text-gray-500"><?php echo e($item->subindice.' .- '.$item->nombre_subindice); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\laragon\www\resproyect\resources\views/livewire/subtemas.blade.php ENDPATH**/ ?>