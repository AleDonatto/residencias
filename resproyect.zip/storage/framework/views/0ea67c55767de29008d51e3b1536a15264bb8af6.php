<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/layouts.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/sidebar.css')); ?>">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    
        <?php echo \Livewire\Livewire::styles(); ?>


        <!-- Scripts -->
        <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.6.0/dist/alpine.js" defer></script>
    </head>
    <body class="font-sans antialiased">
        <div class="min-h-screen bg-gray-100">
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('navigation-dropdown')->html();
} elseif ($_instance->childHasBeenRendered('nQpJE23')) {
    $componentId = $_instance->getRenderedChildComponentId('nQpJE23');
    $componentTag = $_instance->getRenderedChildComponentTagName('nQpJE23');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nQpJE23');
} else {
    $response = \Livewire\Livewire::mount('navigation-dropdown');
    $html = $response->html();
    $_instance->logRenderedChild('nQpJE23', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            <!--aqui va el livewire navigation-dropdown-->

            <!-- sidebar -->
            <div id="sidebar" class="h-screen w-16 menu bg-white text-white px-4 flex items-center nunito static fixed shadow">

                <ul class="list-reset ">
                    <?php if( Auth::user()->tipo_user == 1 ): ?>
                        <?php echo $__env->make('menu.alumnos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php elseif( Auth::user()->tipo_user == 2 ): ?>
                        <?php echo $__env->make('menu.docente', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>
                </ul>
        
            </div>

            <!--contenido-->
            <div class="flex flex-row flex-wrap flex-1 flex-grow content-start pl-16">
                <div class="w-full flex-1">
                    <main>
                        <?php echo e($slot); ?>

                    </main>
                </div>
            </div>
            <!--end contenido-->
        
            <!--end sidebar-->
            <!--<div class="bg-white shadow w-56 h-screen">
                <div class="">
                    <h4>texto</h4>
                </div>
                <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                    <?php echo e($header); ?>

                </div>
            </div>-->


        </div>

        <?php echo $__env->yieldPushContent('modals'); ?>

        <?php echo \Livewire\Livewire::scripts(); ?>

        <?php echo $__env->yieldPushContent('scripts'); ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script src="<?php echo e(asset('js/invitado.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\laragon\www\resproyect\resources\views/layouts/app.blade.php ENDPATH**/ ?>