<li class="my-2 md:my-0">
    <a href="<?php echo e(route('dashboard')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-gray-600 no-underline hover:text-indigo-400">
        <i class="fas fa-home fa-fw mr-3"></i><span class="w-full inline-block pb-1 md:pb-0 text-sm">Home</span>
    </a>
</li>

<?php if( Auth::user()->perfil_completo  ): ?>
<li class="my-2 md:my-0 ">
    <a href="<?php echo e(route('allCursos')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-gray-600 no-underline hover:text-indigo-400">
        <i class="fas fa-chalkboard fa-fw mr-3"></i><span class="w-full inline-block pb-1 md:pb-0 text-sm">Cursos</span>
    </a>
</li>
<li class="my-2 md:my-0 ">
    <a href="<?php echo e(route('cursos_alumnos.index')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-gray-600 no-underline hover:text-indigo-400">
        <i class="fas fa-chalkboard-teacher fa-fw mr-3"></i><span class="w-full inline-block pb-1 md:pb-0 text-sm">Mis Cursos</span>
    </a>
</li>
<li class="my-2 md:my-0 ">
    <a href="<?php echo e(route('horarios_alumnos')); ?>" class="block py-1 md:py-3 pl-1 align-middle text-gray-600 no-underline hover:text-indigo-400">
        <i class="far fa-clock fa-fw mr-3"></i><span class="w-full inline-block pb-1 md:pb-0 text-sm">Mi Horario</span>
    </a>
</li>
<?php endif; ?>

<?php /**PATH C:\laragon\www\resproyect\resources\views/menu/alumnos.blade.php ENDPATH**/ ?>