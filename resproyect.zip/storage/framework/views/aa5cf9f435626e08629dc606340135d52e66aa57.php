<h4 class="font-sans text-gray-600 font-bold text-2xl my-2">Cursos</h4>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('alumnos-cursos')->html();
} elseif ($_instance->childHasBeenRendered('eFwXrxR')) {
    $componentId = $_instance->getRenderedChildComponentId('eFwXrxR');
    $componentTag = $_instance->getRenderedChildComponentTagName('eFwXrxR');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eFwXrxR');
} else {
    $response = \Livewire\Livewire::mount('alumnos-cursos');
    $html = $response->html();
    $_instance->logRenderedChild('eFwXrxR', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?><?php /**PATH C:\laragon\www\resproyect\resources\views/alumnos/viewCursos.blade.php ENDPATH**/ ?>