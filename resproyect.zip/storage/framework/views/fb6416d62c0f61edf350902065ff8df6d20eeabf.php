<div>
    <div class="container mx-auto px-4">
        <?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h2 class="my-5 font-serif text-gray-600 text-2xl text-center">Curso: <?php echo e($item->nombreCurso); ?> </h2>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
        <div class="grid grid-cols-6 gap-4">
            <div class="col-start-2 col-span-4">
                <div class="flex justify-center bg-white">
                    <?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="md:flex rounded-lg p-6 max-w-2xl">
                        <img class="h-16 w-16 md:h-24 md:w-24 rounded-full mx-auto md:mx-0 md:mr-6" src="<?php echo e(Auth::user()->profile_photo_url); ?>">
                        <div class="text-center md:text-left">
                        <h2 class="text-lg capitalize"><?php echo e($item->name.' '.$item->lastname); ?></h2>
                            <div class="text-purple-500">Product Engineer</div>
                            <div class="text-gray-600">erinlindford@example.com</div>
                            <div class="text-gray-600">(555) 765-4321</div>
                        </div>
                    </div>   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                </div>
            </div>
    
          <div class="col-start-1 col-end-3">
            <h4 class="text-3xl text-blue-700">Acerca del curso</h4>
            <div class="">
              <p class="text-sm text-gray-600">
                "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. 
                Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
              </p>
            </div>
  
            <h4 class="text-3xl text-blue-700">Descripcion</h4>
            <div class="">
                <?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <p class="text-sm text-gray-600">
                    "<?php echo e($item->descripcion); ?>"
                  </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>
          
          <div class="col-end-7 col-span-3">
            <h3 class="text-3xl text-blue-700">Contenido del Curso</h3>
            <div class="card mx-5">
              <?php $__currentLoopData = $curso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('temas-materia', ['idMateria' => $item->materia_id])->html();
} elseif ($_instance->childHasBeenRendered('EV9Hvoq')) {
    $componentId = $_instance->getRenderedChildComponentId('EV9Hvoq');
    $componentTag = $_instance->getRenderedChildComponentTagName('EV9Hvoq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EV9Hvoq');
} else {
    $response = \Livewire\Livewire::mount('temas-materia', ['idMateria' => $item->materia_id]);
    $html = $response->html();
    $_instance->logRenderedChild('EV9Hvoq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?></livewire:temas-materia>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
    
    </div>
  
    <div class="container mx-auto px-4 text-center my-5">
        <?php if($solicitudes == 1): ?>
        <p class="animate-pulse"><small class="text-sm text-gray-600">Ya has realizado una solicitud espera a ser aceptado</small></p>
        <button type="button" disabled class="disabled:opacity-50 bg-blue-500 text-white font-bold py-2 px-4 rounded" disabled>
            Enviar Solicitud de Inscrpcion
        </button>
        <?php else: ?>
        <form action="<?php echo e(route('sendSolicitud')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="curso" wire:model="cursoId">
            <input type="hidden" name="alumno" wire:model="alumnoId">

            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Enviar Solicitud de Inscrpcion
            </button>
        </form>
        <?php endif; ?>
    </div>

</div>
<?php /**PATH C:\laragon\www\resproyect\resources\views/livewire/solicitud-inscripcion-alumno.blade.php ENDPATH**/ ?>