<?php return array (
  'alumnos-cursos' => 'App\\Http\\Livewire\\AlumnosCursos',
  'alumnos-socioeconomicos' => 'App\\Http\\Livewire\\AlumnosSocioeconomicos',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'cursos-docente' => 'App\\Http\\Livewire\\CursosDocente',
  'datos-socieconomicos' => 'App\\Http\\Livewire\\DatosSocieconomicos',
  'solicitud-inscripcion-alumno' => 'App\\Http\\Livewire\\SolicitudInscripcionAlumno',
  'subtemas' => 'App\\Http\\Livewire\\Subtemas',
  'temas-materia' => 'App\\Http\\Livewire\\TemasMateria',
);